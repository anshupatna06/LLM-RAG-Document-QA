def chunk_text(text, chunk_size=500, overlap=100):
    chunks = []
    start = 0

    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start = end - overlap

    return chunks

# Combine Documents → Chunks
def process_documents(docs):
    all_chunks = []
    for doc in docs:
        all_chunks.extend(chunk_text(doc))
    return all_chunks
