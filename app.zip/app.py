from embeddings.generate_embeddings import embed_texts
from embeddings.embedding_model import EmbeddingModel


from ingestion import load_documents
from ingestion.chunking import process_documents
from llm.inference import generate_answer
from llm.prompt import build_prompt
from retrieval.similarity import retrieve_top_k


docs = load_documents("data/documents")
chunks = process_documents(docs)

chunk_embeddings = embed_texts(chunks, EmbeddingModel)

question = input("Ask a question: ")
query_embedding = EmbeddingModel(question)

relevant_chunks = retrieve_top_k(query_embedding, chunk_embeddings, chunks)

prompt = build_prompt(relevant_chunks, question)
answer = generate_answer(prompt, llm)

print(answer)
