import numpy as np
def cosine_similarity(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))



# Retrieve Top-K Chunks
def retrieve_top_k(query_embedding, chunk_embeddings, chunks, k=3):
    scores = []

    for i, emb in enumerate(chunk_embeddings):
        score = cosine_similarity(query_embedding, emb)
        scores.append((score, chunks[i]))

    scores.sort(reverse=True, key=lambda x: x[0])
    return [chunk for _, chunk in scores[:k]]
